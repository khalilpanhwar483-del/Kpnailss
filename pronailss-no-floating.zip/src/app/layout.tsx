import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Playfair_Display, Inter } from "next/font/google";
import "./globals.css";

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Lumière Nail Studio — Luxury Nail Care in NYC",
  description:
    "Experience elevated nail care in the heart of New York. Russian gel manicures, luxury pedicures, and bespoke nail art from master technicians.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${playfair.variable} ${inter.variable}`}>
      <body className="bg-[#FCF7FD] text-neutral-900 antialiased font-sans">
        {children}
      </body>
    </html>
  );
}

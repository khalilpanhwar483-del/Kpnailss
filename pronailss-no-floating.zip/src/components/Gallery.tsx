"use client";

import Image from "next/image";
import { useCallback, useEffect, useRef, useState } from "react";

type GalleryItem = {
  src: string;
  alt: string;
  category: string;
};

const ITEMS: GalleryItem[] = [
  {
    src: "https://images.pexels.com/photos/34871563/pexels-photo-34871563.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=700",
    alt: "Red manicure with artistic nail design",
    category: "Nail Art",
  },
  {
    src: "https://images.pexels.com/photos/34885844/pexels-photo-34885844.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=700",
    alt: "Intricate pink nail art with gold ring",
    category: "Nail Art",
  },
  {
    src: "https://images.pexels.com/photos/38283820/pexels-photo-38283820.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=700",
    alt: "Vibrant multicolored manicure",
    category: "Gel",
  },
  {
    src: "https://images.pexels.com/photos/34871556/pexels-photo-34871556.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=700",
    alt: "Red manicure on soft white surface",
    category: "Classic",
  },
  {
    src: "https://images.pexels.com/photos/34835304/pexels-photo-34835304.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=700",
    alt: "Leopard print and black nail art",
    category: "Nail Art",
  },
  {
    src: "https://images.pexels.com/photos/34885845/pexels-photo-34885845.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=700",
    alt: "Red nail art with gold ring on dark background",
    category: "Gel",
  },
  {
    src: "https://images.pexels.com/photos/11124894/pexels-photo-11124894.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=700",
    alt: "Bright orange nails on yellow background",
    category: "Classic",
  },
  {
    src: "https://images.pexels.com/photos/34871555/pexels-photo-34871555.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=700",
    alt: "Red and white manicure",
    category: "Gel",
  },
  {
    src: "https://images.pexels.com/photos/5681794/pexels-photo-5681794.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=700",
    alt: "Hand holding gel polish bottle",
    category: "Studio",
  },
  {
    src: "https://images.pexels.com/photos/6135674/pexels-photo-6135674.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=700",
    alt: "Pedicure salon interior",
    category: "Studio",
  },
  {
    src: "https://images.pexels.com/photos/3997349/pexels-photo-3997349.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=700",
    alt: "Nail polish colour swatches",
    category: "Studio",
  },
  {
    src: "https://images.pexels.com/photos/5619458/pexels-photo-5619458.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=700",
    alt: "Pedicure treatment in progress",
    category: "Studio",
  },
];

const CATEGORIES = ["All", "Nail Art", "Gel", "Classic", "Studio"];

export default function Gallery() {
  const [filter, setFilter] = useState("All");
  const [index, setIndex] = useState(0);
  const [lightbox, setLightbox] = useState<number | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const [bp, setBp] = useState<"sm" | "md" | "lg">("lg");
  const touchX = useRef<number | null>(null);
  const touchY = useRef<number | null>(null);

  const visible =
    filter === "All" ? ITEMS : ITEMS.filter((i) => i.category === filter);
  const total = visible.length;

  // responsive breakpoint watcher
  useEffect(() => {
    const check = () => {
      const w = window.innerWidth;
      setBp(w < 640 ? "sm" : w < 1024 ? "md" : "lg");
    };
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);

  // how many neighbours are visible per breakpoint
  const neighbours = bp === "sm" ? 1 : bp === "md" ? 1 : 2;
  // horizontal spread + rotation per breakpoint
  const spread = bp === "sm" ? 74 : bp === "md" ? 64 : 58;
  const rotate = bp === "sm" ? 0 : bp === "md" ? -16 : -22;

  const go = useCallback(
    (dir: number) => setIndex((i) => (i + dir + total) % total),
    [total]
  );

  const onTouchStart = (e: React.TouchEvent) => {
    touchX.current = e.touches[0].clientX;
    touchY.current = e.touches[0].clientY;
  };

  const onTouchEnd = (e: React.TouchEvent) => {
    if (touchX.current === null || touchY.current === null) return;
    const dx = e.changedTouches[0].clientX - touchX.current;
    const dy = e.changedTouches[0].clientY - touchY.current;
    // only treat as swipe when mostly horizontal
    if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy)) {
      go(dx < 0 ? 1 : -1);
    }
    touchX.current = null;
    touchY.current = null;
  };

  const stop = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
  }, []);

  const start = useCallback(() => {
    stop();
    timerRef.current = setInterval(() => {
      setIndex((i) => (i + 1) % total);
    }, 4000);
  }, [stop, total]);

  useEffect(() => {
    if (lightbox === null) start();
    return stop;
  }, [start, stop, lightbox, filter]);

  useEffect(() => {
    setIndex(0);
  }, [filter]);

  // lightbox keyboard
  useEffect(() => {
    if (lightbox === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setLightbox(null);
      if (e.key === "ArrowLeft") setLightbox((i) => (i === null ? null : (i - 1 + total) % total));
      if (e.key === "ArrowRight") setLightbox((i) => (i === null ? null : (i + 1) % total));
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [lightbox, total]);

  // offset relative position for 3D coverflow
  const offsetOf = (i: number) => {
    let d = i - index;
    if (d > total / 2) d -= total;
    if (d < -total / 2) d += total;
    return d;
  };

  return (
    <div>
      {/* filters */}
      <div className="flex gap-2 sm:gap-3 mb-8 sm:mb-12 md:mb-14 overflow-x-auto no-scrollbar px-1 pb-1 sm:flex-wrap sm:justify-center sm:overflow-visible">
        {CATEGORIES.map((c) => (
          <button
            key={c}
            onClick={() => setFilter(c)}
            className={`shrink-0 px-4 sm:px-5 py-2 sm:py-2.5 rounded-full text-[10px] sm:text-xs uppercase tracking-wider sm:tracking-widest border transition ${
              filter === c
                ? "bg-gradient-to-r from-[#4A1533] to-[#9D4B8F] text-white border-transparent shadow-lg shadow-[#9D4B8F]/30"
                : "bg-white/60 text-[#6B1F45] border-[#D9A7E0]/60 hover:border-[#9D4B8F] hover:text-[#9D4B8F]"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {/* coverflow carousel */}
      <div
        className="relative w-full overflow-hidden h-[380px] xs:h-[420px] sm:h-[480px] md:h-[540px] lg:h-[580px] select-none touch-pan-y"
        onMouseEnter={stop}
        onMouseLeave={start}
        onTouchStart={onTouchStart}
        onTouchEnd={onTouchEnd}
        style={{ perspective: bp === "sm" ? "none" : "1600px" }}
      >
        {visible.map((item, i) => {
          const d = offsetOf(i);
          const abs = Math.abs(d);
          if (abs > neighbours) return null;

          const isActive = d === 0;
          const scale = isActive ? 1 : abs === 1 ? (bp === "sm" ? 0.78 : 0.82) : 0.66;

          return (
            <button
              key={item.src}
              onClick={() => (isActive ? setLightbox(i) : setIndex(i))}
              aria-label={isActive ? "Open image" : "Go to image"}
              className="absolute top-1/2 left-1/2 rounded-3xl sm:rounded-[28px] overflow-hidden transition-all duration-700 ease-out"
              style={{
                width: "clamp(190px, 62vw, 380px)",
                height: "clamp(280px, 86vw, 520px)",
                maxHeight: "100%",
                transform: `translate(-50%, -50%) translateX(${
                  d * spread
                }%) scale(${scale}) rotateY(${d * rotate}deg)`,
                zIndex: 10 - abs,
                opacity: abs > 1 ? 0.3 : abs === 1 && bp === "sm" ? 0.55 : 1,
                filter: isActive ? "none" : "blur(1.5px) saturate(0.8)",
                boxShadow: isActive
                  ? "0 30px 70px -20px rgba(74,21,51,0.55)"
                  : "0 16px 40px -20px rgba(74,21,51,0.4)",
              }}
            >
              <Image
                src={item.src}
                alt={item.alt}
                fill
                sizes="(max-width: 768px) 60vw, 380px"
                className="object-cover"
              />

              {/* aesthetic gradient veil */}
              <div
                className={`absolute inset-0 transition ${
                  isActive
                    ? "bg-gradient-to-t from-[#4A1533]/80 via-[#4A1533]/10 to-transparent"
                    : "bg-[#4A1533]/35"
                }`}
              />

              {/* inner glow border */}
              <div className="absolute inset-0 rounded-[28px] ring-1 ring-inset ring-white/30" />

              {isActive && (
                <div className="absolute inset-x-0 bottom-0 p-4 sm:p-5 md:p-6 text-left">
                  <span className="inline-block mb-1.5 sm:mb-2 text-[9px] sm:text-[10px] uppercase tracking-[0.2em] sm:tracking-[0.25em] text-white/90 bg-white/20 backdrop-blur px-2.5 sm:px-3 py-1 rounded-full">
                    {item.category}
                  </span>
                  <p className="font-serif text-white text-sm sm:text-base md:text-lg leading-snug line-clamp-2">
                    {item.alt}
                  </p>
                  <span className="mt-2 sm:mt-3 inline-flex items-center gap-1.5 sm:gap-2 text-[9px] sm:text-[11px] uppercase tracking-[0.15em] sm:tracking-[0.2em] text-[#D9A7E0]">
                    Tap to enlarge
                    <svg className="w-3 h-3 sm:w-3.5 sm:h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7" strokeLinecap="round" />
                    </svg>
                  </span>
                </div>
              )}
            </button>
          );
        })}

        {/* arrows */}
        <button
          aria-label="Previous"
          onClick={() => go(-1)}
          className="absolute z-20 top-1/2 -translate-y-1/2 left-1 sm:left-3 md:left-6 w-10 h-10 sm:w-12 sm:h-12 rounded-full glass-card text-[#4A1533] flex items-center justify-center hover:bg-[#4A1533] hover:text-white transition shadow-lg"
        >
          <svg className="w-4 h-4 sm:w-5 sm:h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M15 18l-6-6 6-6" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <button
          aria-label="Next"
          onClick={() => go(1)}
          className="absolute z-20 top-1/2 -translate-y-1/2 right-1 sm:right-3 md:right-6 w-10 h-10 sm:w-12 sm:h-12 rounded-full glass-card text-[#4A1533] flex items-center justify-center hover:bg-[#4A1533] hover:text-white transition shadow-lg"
        >
          <svg className="w-4 h-4 sm:w-5 sm:h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M9 18l6-6-6-6" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>

        {/* swipe hint on mobile */}
        <div className="sm:hidden absolute bottom-1 left-1/2 -translate-x-1/2 z-20 text-[9px] uppercase tracking-[0.2em] text-[#6B1F45]/70 flex items-center gap-1.5">
          <svg className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M5 12h14M5 12l4-4M5 12l4 4M19 12l-4-4M19 12l-4 4" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          Swipe
        </div>
      </div>

      {/* dots + counter */}
      <div className="mt-6 sm:mt-10 flex flex-col items-center gap-3">
        <div className="flex justify-center gap-1.5 sm:gap-2 flex-wrap max-w-full px-4">
          {visible.map((_, i) => (
            <button
              key={i}
              aria-label={`Go to image ${i + 1}`}
              onClick={() => setIndex(i)}
              className={`h-1.5 sm:h-2 rounded-full transition-all ${
                i === index
                  ? "w-6 sm:w-8 bg-gradient-to-r from-[#4A1533] to-[#9D4B8F]"
                  : "w-1.5 sm:w-2 bg-[#D9A7E0]"
              }`}
            />
          ))}
        </div>
        <p className="text-[10px] sm:text-xs uppercase tracking-[0.25em] text-[#6B1F45]/70">
          {index + 1} / {total}
        </p>
      </div>

      {/* lightbox */}
      {lightbox !== null && visible[lightbox] && (
        <div
          className="fixed inset-0 z-[60] bg-[#2c0d20]/95 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setLightbox(null)}
        >
          <button
            aria-label="Close"
            onClick={() => setLightbox(null)}
            className="absolute top-3 right-3 sm:top-5 sm:right-5 w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-white/10 hover:bg-white/25 text-white flex items-center justify-center transition z-10"
          >
            <svg className="w-4 h-4 sm:w-5 sm:h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M6 6l12 12M18 6L6 18" strokeLinecap="round" />
            </svg>
          </button>

          <button
            aria-label="Previous image"
            onClick={(e) => {
              e.stopPropagation();
              setLightbox((i) => (i === null ? null : (i - 1 + total) % total));
            }}
            className="absolute left-2 sm:left-4 md:left-8 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/10 hover:bg-white/25 text-white flex items-center justify-center transition z-10"
          >
            <svg className="w-5 h-5 sm:w-[22px] sm:h-[22px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M15 18l-6-6 6-6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>

          <button
            aria-label="Next image"
            onClick={(e) => {
              e.stopPropagation();
              setLightbox((i) => (i === null ? null : (i + 1) % total));
            }}
            className="absolute right-2 sm:right-4 md:right-8 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/10 hover:bg-white/25 text-white flex items-center justify-center transition z-10"
          >
            <svg className="w-5 h-5 sm:w-[22px] sm:h-[22px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M9 18l6-6-6-6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>

          <figure
            className="relative w-full max-w-3xl px-12 sm:px-16"
            onClick={(e) => e.stopPropagation()}
            onTouchStart={onTouchStart}
            onTouchEnd={(e) => {
              if (touchX.current === null) return;
              const dx = e.changedTouches[0].clientX - touchX.current;
              if (Math.abs(dx) > 45) {
                setLightbox((i) =>
                  i === null ? null : (i + (dx < 0 ? 1 : -1) + total) % total
                );
              }
              touchX.current = null;
              touchY.current = null;
            }}
          >
            <div className="relative w-full h-[60vh] sm:h-[65vh] md:h-[70vh] rounded-xl sm:rounded-2xl overflow-hidden ring-1 ring-[#D9A7E0]/40">
              <Image
                src={visible[lightbox].src}
                alt={visible[lightbox].alt}
                fill
                sizes="90vw"
                className="object-contain"
              />
            </div>
            <figcaption className="mt-3 sm:mt-4 text-center text-xs sm:text-sm text-[#F5E6F7]/85 px-2">
              {visible[lightbox].alt}
              <span className="block sm:inline sm:before:content-['_·_']">
                {lightbox + 1} / {total}
              </span>
            </figcaption>
          </figure>
        </div>
      )}
    </div>
  );
}
